#include "lcd.h"
#include "Arial12x12.h"

uint8_t buffer[512];
uint16_t positionL1 = 0;
uint16_t positionL2 = 0;

static GPIO_InitTypeDef GPIO_InitStruct;

/* SPI Driver */
 extern ARM_DRIVER_SPI Driver_SPI1;
ARM_DRIVER_SPI* SPIdrv = &Driver_SPI1; 

void LCD_reset(void){
    /* Initialize the SPI driver */
    SPIdrv->Initialize(NULL);
    /* Power up the SPI peripheral */
    SPIdrv->PowerControl(ARM_POWER_FULL);
    /* Configure the SPI to Master, 8-bit mode @10000 kBits/sec */
    SPIdrv->Control(ARM_SPI_MODE_MASTER | ARM_SPI_CPOL1_CPHA1 | ARM_SPI_MSB_LSB | ARM_SPI_DATA_BITS(8), 1000000);
 
    /* SS line = INACTIVE = HIGH */
    SPIdrv->Control(ARM_SPI_CONTROL_SS, ARM_SPI_SS_INACTIVE);
  
  // Inicializacion de GPIO
    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOD_CLK_ENABLE();
    __HAL_RCC_GPIOF_CLK_ENABLE();
    
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_PULLDOWN;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;

// RESET
    GPIO_InitStruct.Pin = GPIO_PIN_6;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
    HAL_GPIO_WritePin(GPIOA,GPIO_PIN_6, GPIO_PIN_SET);
    
// A0
    GPIO_InitStruct.Pin = GPIO_PIN_13;
    HAL_GPIO_Init(GPIOF, &GPIO_InitStruct);
    HAL_GPIO_WritePin(GPIOF,GPIO_PIN_13, GPIO_PIN_SET);

// CS
    GPIO_InitStruct.Pin = GPIO_PIN_14;
    HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);
    HAL_GPIO_WritePin(GPIOD,GPIO_PIN_14, GPIO_PIN_SET);


    HAL_GPIO_WritePin(GPIOA,GPIO_PIN_6, GPIO_PIN_RESET);
    HAL_Delay(1);
    HAL_GPIO_WritePin(GPIOA,GPIO_PIN_6, GPIO_PIN_SET);
    HAL_Delay(1);
}


    //LCD_wr_data: Funci�n que escribe un dato en el LCD.
void LCD_wr_data(unsigned char data){ //env�a un byte de datos al LCD mediante SPI
      ARM_SPI_STATUS status;
    // Seleccionar CS = 0;
      HAL_GPIO_WritePin(GPIOD,GPIO_PIN_14, GPIO_PIN_RESET);
    // Seleccionar A0 = 1;
      HAL_GPIO_WritePin(GPIOF,GPIO_PIN_13, GPIO_PIN_SET);
    // Escribir un dato (data) usando la funci�n SPIDrv->Send(�);
      SPIdrv->Send(&data, sizeof(data));
    // Esperar a que se libere el bus SPI;
      do
      {
      status = SPIdrv->GetStatus();
      }
      while (status.busy);
    // Seleccionar CS = 1;
      HAL_GPIO_WritePin(GPIOD,GPIO_PIN_14, GPIO_PIN_SET);

}
    //LCD_wr_cmd: Funci�n que escribe un comando en el LCD.
void LCD_wr_cmd(unsigned char cmd){
      ARM_SPI_STATUS status;
    // Seleccionar CS = 0;
      HAL_GPIO_WritePin(GPIOD,GPIO_PIN_14, GPIO_PIN_RESET);
    // Seleccionar A0 = 0;
      HAL_GPIO_WritePin(GPIOF,GPIO_PIN_13, GPIO_PIN_RESET);
    // Escribir un comando (cmd) usando la funci�n SPIDrv->Send(�);
      SPIdrv->Send(&cmd, sizeof(cmd));
    // Esperar a que se libere el bus SPI;
      do
      {
      status = SPIdrv->GetStatus();
      }
      while (status.busy);
    // Seleccionar CS = 1;
      HAL_GPIO_WritePin(GPIOD,GPIO_PIN_14, GPIO_PIN_SET);
}
    
    // Inicializaci�n del LCD
void LCD_init(void) {
     LCD_wr_cmd(0xAE);//Display off
    LCD_wr_cmd(0xA2); //Fija el valor de la relaci�n de la tensi�n de polarizaci�n del LCD a 1/9
    LCD_wr_cmd(0xA0); //El direccionamiento de la RAM de datos del display es la normal
    LCD_wr_cmd(0xC8); //El scan en las salidas COM es el normal
    LCD_wr_cmd(0x22); //Fija la relaci�n de resistencias interna a 2
    LCD_wr_cmd(0x2F); //Power on
    LCD_wr_cmd(0x40); //Display empieza en la l�nea 0
    LCD_wr_cmd(0xAF); // Display ON
    LCD_wr_cmd(0x81); //Contraste
    LCD_wr_cmd(0x17); //Valor Contraste (debe determinarlo y configurarlo a su gusto)
    LCD_wr_cmd(0xA4); //Display all points normal
    LCD_wr_cmd(0xA6); //LCD Display normal


    }
      
void LCD_update(void){
     int i;
     LCD_wr_cmd(0x00); // 4 bits de la parte baja de la direcci�n a 0
     LCD_wr_cmd(0x10); // 4 bits de la parte alta de la direcci�n a 0
     LCD_wr_cmd(0xB0); // P�gina 0
     
     for(i=0;i<128;i++){
     LCD_wr_data(buffer[i]);
     }

     LCD_wr_cmd(0x00); // 4 bits de la parte baja de la direcci�n a 0
     LCD_wr_cmd(0x10); // 4 bits de la parte alta de la direcci�n a 0
     LCD_wr_cmd(0xB1); // P�gina 1

     
     for(i=128;i<256;i++){
     LCD_wr_data(buffer[i]);
     }

     LCD_wr_cmd(0x00);
     LCD_wr_cmd(0x10);
     LCD_wr_cmd(0xB2); //P�gina 2
     for(i=256;i<384;i++){
     LCD_wr_data(buffer[i]);
     }

     LCD_wr_cmd(0x00);
     LCD_wr_cmd(0x10);
     LCD_wr_cmd(0xB3); // Pagina 3


     for(i=384;i<512;i++){
      LCD_wr_data(buffer[i]);
     }
}
    

void symbolToLocalBuffer(uint8_t line,uint8_t symbol){
   uint8_t i, value1, value2;
      uint16_t offset=0;

      offset=25*(symbol - ' ');
      if(line == 1){
        
         for (i=0; i<12; i++){

          value1=Arial12x12[offset+i*2+1];
          value2=Arial12x12[offset+i*2+2];

          buffer[i+positionL1]=value1;
          buffer[i+128+positionL1]=value2; // +128 en ambos baja una linea en el LCD
    }
          positionL1=positionL1+Arial12x12[offset];
}  else {
      for (i=0; i<12; i++){

          value1=Arial12x12[offset+i*2+1];
          value2=Arial12x12[offset+i*2+2];

          buffer[i+256+positionL2]=value1;
          buffer[i+384+positionL2]=value2; // +128 en ambos baja una linea en el LCD
    }
          positionL2=positionL2+Arial12x12[offset];
  }
}

void charToLocalBuffer(uint8_t line, const char *text){
if(line == 1){
positionL1 = 0;
} else if(line == 2){
positionL2 = 0;
}

for(int k = 0; text[k] != '\0'; k++){
symbolToLocalBuffer(line, (uint8_t)text[k]);
}
}

void LCD_clean(void){
  int i;
    for(i=0;i<512;i++){
      buffer[i] = 0x00;
    }
}