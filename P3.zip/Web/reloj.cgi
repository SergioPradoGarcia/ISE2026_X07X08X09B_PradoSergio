t <html><head><title>RTC: Hora y Fecha</title>
t <meta http-equiv="refresh" content="1">
t </head>
i pg_header.inc
t <h2 align=center><br>Control RTC: Hora y Fecha</h2>
t <table border=0 width=99%><font size="3">
t <tr bgcolor=#aaccff>
t  <th width=40%>Campo</th>
t  <th width=60%>Valor</th></tr>
# Here begin data setting which is formatted in HTTP_CGI.C module
t <tr><td>Hora</td>
c r 1 <td>%s</td></tr>
t <tr><td>Fecha</td>
c r 2 <td>%s</td></tr>
t </font></table>
i pg_footer.inc
. End of script must be closed with period.