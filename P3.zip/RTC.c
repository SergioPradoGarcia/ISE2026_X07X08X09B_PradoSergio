#include "rtc.h"
#include <stdio.h>

#include <time.h>        /* Magia para que entienda struct tm y localtime */
#include "rl_net.h"      /* Magia para que entienda SNTP y NET_ADDR */
#include "cmsis_os2.h"   /* Magia para que entienda osTimerId_t */

RTC_HandleTypeDef hrtc;
osTimerId_t tim_id_500msR;
RTC_TimeTypeDef stimestructureget;
RTC_DateTypeDef sdatestructureget;
RTC_DateTypeDef sdatestructure = {0};
RTC_TimeTypeDef stimestructure = {0};

/* Funciones privadas (solo se usan aqu� dentro) */
static void RTC_CalendarConfig(void);
static void RTC_AlarmConfig(void);

const NET_ADDR4 ntp_server = { NET_ADDR_IP4, 0, 216, 239, 35, 0 }; //direccion ip de servidor atomico de google


void RTC_Alarm_IRQHandler(void)
{
  HAL_RTC_AlarmIRQHandler(&hrtc);
}

void RTC_Init(void)
{
  hrtc.Instance = RTC;
  hrtc.Init.HourFormat = RTC_HOURFORMAT_24;
  /* Configuraci�n t�pica para el cristal LSE de 32.768 kHz */
  hrtc.Init.AsynchPrediv = 127;
  hrtc.Init.SynchPrediv = 255;
  hrtc.Init.OutPut = RTC_OUTPUT_DISABLE;
  hrtc.Init.OutPutPolarity = RTC_OUTPUT_POLARITY_HIGH;
  hrtc.Init.OutPutType = RTC_OUTPUT_TYPE_OPENDRAIN;

  if (HAL_RTC_Init(&hrtc) != HAL_OK) {
    /* Error de inicializaci�n */
  }

  /* Comprobamos si el RTC ya tiene la hora guardada usando el registro de Backup */
  /* Si no coincide con nuestro c�digo m�gico (0x32F2), significa que perdi� la bater�a */
  if(HAL_RTCEx_BKUPRead(&hrtc, RTC_BKP_DR1) != 0x32F2)
  {
    RTC_CalendarConfig(); // Ponemos la hora constante
  }

  /* Configuramos la alarma de 1 minuto */
  RTC_AlarmConfig();
}

static void RTC_CalendarConfig(void)
{
  RTC_DateTypeDef sdatestructure;
  RTC_TimeTypeDef stimestructure;

  /* Fecha de inicio de la pr�ctica: 6 de Marzo de 2026 */
  sdatestructure.Year = 0x26;
  sdatestructure.Month = RTC_MONTH_MARCH;
  sdatestructure.Date = 0x06;
  sdatestructure.WeekDay = RTC_WEEKDAY_FRIDAY;
  HAL_RTC_SetDate(&hrtc, &sdatestructure, RTC_FORMAT_BCD);

  /* Hora constante: 12:00:00 */
  stimestructure.Hours = 0x12;
  stimestructure.Minutes = 0x00;
  stimestructure.Seconds = 0x00;
  stimestructure.TimeFormat = RTC_HOURFORMAT12_AM;
  stimestructure.DayLightSaving = RTC_DAYLIGHTSAVING_NONE;
  stimestructure.StoreOperation = RTC_STOREOPERATION_RESET;
  HAL_RTC_SetTime(&hrtc, &stimestructure, RTC_FORMAT_BCD);

  /* Escribimos el c�digo m�gico en el registro de Backup para no volver a inicializar */
  HAL_RTCEx_BKUPWrite(&hrtc, RTC_BKP_DR1, 0x32F2);
}

static void RTC_AlarmConfig(void)
{
  RTC_AlarmTypeDef sAlarm = {0};

  /* Queremos que salte cada vez que el segundo sea "00" (cada minuto) */
  sAlarm.AlarmTime.Hours = 0x00;
  sAlarm.AlarmTime.Minutes = 0x00;
  sAlarm.AlarmTime.Seconds = 0x00;
  
  /* Enmascaramos (ignoramos) el d�a, hora y minuto. As� salta cada minuto. */
  sAlarm.AlarmMask = RTC_ALARMMASK_DATEWEEKDAY | RTC_ALARMMASK_HOURS | RTC_ALARMMASK_MINUTES;
  sAlarm.AlarmSubSecondMask = RTC_ALARMSUBSECONDMASK_ALL;
  sAlarm.AlarmDateWeekDaySel = RTC_ALARMDATEWEEKDAYSEL_DATE;
  sAlarm.AlarmDateWeekDay = 0x01;
  sAlarm.Alarm = RTC_ALARM_A;

  HAL_RTC_SetAlarm_IT(&hrtc, &sAlarm, RTC_FORMAT_BCD);
}

/* Funci�n para que el main pueda leer la hora y pasarla al LCD */
void RTC_CalendarShow(char *showtime, char *showdate)
{
  //RTC_DateTypeDef sdatestructureget;
  //RTC_TimeTypeDef stimestructureget;

  /* IMPORTANTE: Leer Time siempre antes que Date, es un requisito del hardware */
  HAL_RTC_GetTime(&hrtc, &stimestructureget, RTC_FORMAT_BIN);
  HAL_RTC_GetDate(&hrtc, &sdatestructureget, RTC_FORMAT_BIN);
  
  sprintf(showtime, "Hora: %02d:%02d:%02d", stimestructureget.Hours, stimestructureget.Minutes, stimestructureget.Seconds);
  sprintf(showdate, "Fecha: %02d/%02d/20%02d", sdatestructureget.Date, sdatestructureget.Month, sdatestructureget.Year);
}

/* Esta funci�n baja a nivel de hardware para encender el reloj. El HAL la llama sola. */
void HAL_RTC_MspInit(RTC_HandleTypeDef* rtcHandle)
{
  if(rtcHandle->Instance==RTC)
  {
    /* Encendemos los relojes de energ�a y backup */
    __HAL_RCC_PWR_CLK_ENABLE();
    HAL_PWR_EnableBkUpAccess();
    
    /* Encendemos el cristal LSE (Low Speed External) */
    __HAL_RCC_LSE_CONFIG(RCC_LSE_ON);
    
    /* Esperamos a que el cristal est� listo */
    while(__HAL_RCC_GET_FLAG(RCC_FLAG_LSERDY) == RESET) {}
    
    /* Seleccionamos el LSE como fuente del RTC y lo encendemos */
    __HAL_RCC_RTC_CONFIG(RCC_RTCCLKSOURCE_LSE);
    __HAL_RCC_RTC_ENABLE();

    /* Activamos las interrupciones para la Alarma */
    HAL_NVIC_SetPriority(RTC_Alarm_IRQn, 5, 0);
    HAL_NVIC_EnableIRQ(RTC_Alarm_IRQn);
  }
}

void Parpadeo_led_rojo(void){
	osTimerStart(tim_id_500msR,500);	
}

struct tm ts;

void get_time (void) {
  if (netSNTPc_GetTime ((NET_ADDR *)&ntp_server, time_callback) == netOK) {
    //printf ("SNTP request sent.\n");
  }
  else {
    //printf ("SNTP not ready or bad parameters.\n");
  }
}
static void time_callback (uint32_t seconds, uint32_t seconds_fraction){
//	RTC_DateTypeDef sdatestructure = {0};
//  RTC_TimeTypeDef stimestructure = {0};
  if (seconds == 0) {
    //printf ("Server not responding or bad response.\n");
  }
	else{
    // Format time, "ddd yyyy-mm-dd hh:mm:ss zzz"
    ts = *localtime(&seconds);
		/*##-1- Configure the Date #################################################*/
		sdatestructure.Year = ts.tm_year-100;
		if(ts.tm_mon==12){
			sdatestructure.Month = 1;
		}else{
		sdatestructure.Month = ts.tm_mon+1;
		}
		sdatestructure.Date = ts.tm_mday;
		sdatestructure.WeekDay = ts.tm_wday;
		HAL_RTC_SetDate(&hrtc, &sdatestructure, RTC_FORMAT_BIN);
		/*##-2- Configure the Time #################################################*/
		if(ts.tm_hour==22){
			stimestructure.Hours = 0;
		}else if(ts.tm_hour==23){
			stimestructure.Hours = 1;
		}else{
		stimestructure.Hours = ts.tm_hour+2;
		}
		stimestructure.Minutes = ts.tm_min;
		stimestructure.Seconds = ts.tm_sec;
		stimestructure.StoreOperation = RTC_STOREOPERATION_RESET;
		HAL_RTC_SetTime(&hrtc, &stimestructure, RTC_FORMAT_BIN);
		RTC_AlarmConfig();
  }
}

void reset_tiempo(void){
		/*##-1- Configure the Date #################################################*/
		sdatestructure.Year = 0;
		sdatestructure.Month = 1;
		sdatestructure.Date = 1;
		sdatestructure.WeekDay = ts.tm_wday;
		HAL_RTC_SetDate(&hrtc, &sdatestructure, RTC_FORMAT_BIN);
		/*##-2- Configure the Time #################################################*/
		stimestructure.Hours = 0;
		stimestructure.Minutes = 0;
		stimestructure.Seconds = 0;
		stimestructure.StoreOperation = RTC_STOREOPERATION_RESET;
		HAL_RTC_SetTime(&hrtc, &stimestructure, RTC_FORMAT_BIN);
		RTC_AlarmConfig();
}
