/*------------------------------------------------------------------------------
 * MDK Middleware - Component ::Network
 * Copyright (c) 2004-2019 Arm Limited (or its affiliates). All rights reserved.
 *------------------------------------------------------------------------------
 * Name:    HTTP_Server.c
 * Purpose: HTTP Server example
 *----------------------------------------------------------------------------*/

#include <stdio.h>

#include "main.h"

#include "rl_net.h"                     // Keil.MDK-Pro::Network:CORE

#include "stm32f4xx_hal.h"              // Keil::Device:STM32Cube HAL:Common
#include "Board_LED.h"                  // ::Board Support:LED
#include "Board_Buttons.h"              // ::Board Support:Buttons
#include "Board_ADC.h"                  // ::Board Support:A/D Converter
#include "Board_GLCD.h"                 // ::Board Support:Graphic LCD
//#include "GLCD_Config.h"                // Keil.MCBSTM32F400::Board Support:Graphic LCD
#include "lcd.h"
#include "adc.h"
#include "rtc.h"
#include "User_boton.h"



// Main stack size must be multiple of 8 Bytes
#define APP_MAIN_STK_SZ (1024U)
uint64_t app_main_stk[APP_MAIN_STK_SZ / 8];
const osThreadAttr_t app_main_attr = {
  .stack_mem  = &app_main_stk[0],
  .stack_size = sizeof(app_main_stk)
};

//extern GLCD_FONT GLCD_Font_6x8;
//extern GLCD_FONT GLCD_Font_16x24;

extern uint16_t AD_in          (uint32_t ch);
extern uint8_t  get_button     (void);
extern void     netDHCP_Notify (uint32_t if_num, uint8_t option, const uint8_t *val, uint32_t len);

//extern bool LEDrun;
//extern char lcd_text[2][20+1];

/* Variable para controlar el parpadeo de la alarma de forma segura */
uint8_t contador_alarma = 0;
/* Variable global para saber si nos ha despertado el bot�n o ha sido una falsa alarma */
volatile uint8_t boton_pulsado = 0;

extern osThreadId_t TID_Display;
extern osThreadId_t TID_Led;



bool LEDrun;
char lcd_text[2][20+1] = { "LCD line 1",
                           "LCD line 2" };

/* Thread IDs */
osThreadId_t TID_Display;
osThreadId_t TID_Led;
osThreadId_t TID_SNTP;
osThreadId_t TID_ParpadeoVerde;
osThreadId_t TID_SleepControl;

/* Thread declarations */
static void BlinkLed (void *arg);
static void Display  (void *arg);
static void Parpadeo_Verde_Thread (void *arg);
static void Sleep_Control_Thread (void *arg);

__NO_RETURN void app_main (void *arg);

/* Read analog inputs */
uint16_t AD_in (uint32_t ch) {
  int32_t val = 0;

  //if (ch == 0) {
    //ADC_StartConversion();
    //while (ADC_ConversionDone () < 0);
    //val = ADC_GetValue();
 // }
  if (ch == 0){
      ADC_Init_Single_Conversion(&adcHANDLE, ADC1);
      val =  ADC_getVoltage(&adcHANDLE, 10 )*4096/3.3f;
  }
  return ((uint16_t)val);
}

/* Read digital inputs */
uint8_t get_button (void) {
  return ((uint8_t)Buttons_GetState ());
}

/* IP address change notification */
void netDHCP_Notify (uint32_t if_num, uint8_t option, const uint8_t *val, uint32_t len) {

  (void)if_num;
  (void)val;
  (void)len;

  if (option == NET_DHCP_OPTION_IP_ADDRESS) {
    /* IP address change, trigger LCD update */
    osThreadFlagsSet (TID_Display, 0x01);
  }
}

/*----------------------------------------------------------------------------
  Thread 'Display': LCD display handler
 *---------------------------------------------------------------------------*/
static __NO_RETURN void Display (void *arg) {
  static uint8_t ip_addr[NET_ADDR_IP6_LEN];
  static char    ip_ascii[40];
  static char    buf[24];
  uint32_t x = 0;
  LCD_reset();
  LCD_init();
  LCD_clean();
  charToLocalBuffer(1, "iniciando red...");
  LCD_update();
  RTC_Init();
  
  (void)arg;

//  GLCD_Initialize         ();
//  GLCD_SetBackgroundColor (GLCD_COLOR_BLUE);
//  GLCD_SetForegroundColor (GLCD_COLOR_WHITE);
//  GLCD_ClearScreen        ();
//  GLCD_SetFont            (&GLCD_Font_16x24);
//  GLCD_DrawString         (x*16U, 1U*24U, "       MDK-MW       ");
//  GLCD_DrawString         (x*16U, 2U*24U, "HTTP Server example ");

//  GLCD_DrawString (x*16U, 4U*24U, "IP4:Waiting for DHCP");

//  /* Print Link-local IPv6 address */
//  netIF_GetOption (NET_IF_CLASS_ETH,
//                   netIF_OptionIP6_LinkLocalAddress, ip_addr, sizeof(ip_addr));

//  netIP_ntoa(NET_ADDR_IP6, ip_addr, ip_ascii, sizeof(ip_ascii));

//  sprintf (buf, "IP6:%.16s", ip_ascii);
//  //GLCD_DrawString ( x    *16U, 5U*24U, buf);
//  sprintf (buf, "%s", ip_ascii+16);
//  //GLCD_DrawString ((x+10U)*16U, 6U*24U, buf);

  while(1) {
    /* Wait for signal from DHCP */
    osThreadFlagsWait (0x01U, osFlagsWaitAny, 1000U);

    /* Retrieve and print IPv4 address */
    netIF_GetOption (NET_IF_CLASS_ETH,
                     netIF_OptionIP4_Address, ip_addr, sizeof(ip_addr));

    netIP_ntoa (NET_ADDR_IP4, ip_addr, ip_ascii, sizeof(ip_ascii));

//    sprintf (buf, "IP4:%-16s",ip_ascii);
//    //GLCD_DrawString (x*16U, 4U*24U, buf);

//    /* Display user text lines */
//    sprintf (buf, "%-20s", lcd_text[0]);
//    //GLCD_DrawString (x*16U, 7U*24U, buf);
//    sprintf (buf, "%-20s", lcd_text[1]);
//    //GLCD_DrawString (x*16U, 8U*24U, buf);
    
    
    /* Le pedimos a tu librer�a RTC que actualice el texto */
    RTC_CalendarShow(lcd_text[0], lcd_text[1]); //Rellena los arrays con la fecha y la hora
    
    LCD_clean();
    charToLocalBuffer(1, lcd_text[0]);
    charToLocalBuffer(2, lcd_text[1]);
    LCD_update();
  }
}



/* Esta funci�n se ejecuta autom�ticamente cuando pasa 1 minuto */
void HAL_RTC_AlarmAEventCallback(RTC_HandleTypeDef *hrtc)
{
  /* Le decimos al hilo BlinkLed que parpadee durante 5 segundos (50 ciclos de 100ms) */
  contador_alarma = 50; 
}

/*----------------------------------------------------------------------------
  Thread 'BlinkLed': Blink the LEDs on an eval board
 *---------------------------------------------------------------------------*/
static __NO_RETURN void BlinkLed (void *arg) {
  const uint8_t led_val[16] = { 0x48,0x88,0x84,0x44,0x42,0x22,0x21,0x11,
                                0x12,0x0A,0x0C,0x14,0x18,0x28,0x30,0x50 };
  uint32_t cnt = 0U;

  (void)arg;

  LEDrun = true;
  while(1) {
    /* Si la alarma salt�, parpadeamos el LED verde r�pido */
    if(contador_alarma > 0) {
        contador_alarma--;
        if(contador_alarma % 2 == 0) LED_On(0); // Encendemos
        else LED_Off(0);                        // Apagamos
    }
    /* Si no hay alarma, hacemos el patr�n normal de Keil */
    /* Every 100 ms */
    else if (LEDrun == true) {
      LED_SetOut (led_val[cnt]);
      if (++cnt >= sizeof(led_val)) {
        cnt = 0U;
      }
    }
    osDelay (100);
  }
}

/* Hilo dedicado a sincronizar la hora por Internet */
static __NO_RETURN void SNTP_Thread(void *arg) {
	osDelay(5000);
	get_time();
	 while (1) {
		osDelay(180000);
		get_time();
		Parpadeo_led_rojo();
	 }
}

/* El procesador saltar� aqu� autom�ticamente al pulsar el bot�n */
void EXTI15_10_IRQHandler(void) {
    /* Limpiamos el "chivato" de la interrupci�n para que no se quede bloqueado */
    HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_13);
  /* �Avisamos a nuestro c�digo de que ha sido el bot�n! */
    boton_pulsado = 1;
}

/* Hilo 1: Parpadeo constante del LED verde cada 100ms */
__NO_RETURN void Parpadeo_Verde_Thread(void *arg) {
    (void)arg;
    while(1) {
        HAL_GPIO_TogglePin(GPIOB, GPIO_PIN_0); // PB0 es el LED Verde
        osDelay(100);
    }
}

/* Hilo 2: Controlador del modo Sleep */
__NO_RETURN void Sleep_Control_Thread(void *arg) {
    (void)arg;
    
    /* 1. Esperamos 15 segundos de ejecuci�n normal */
    osDelay(15000);
    
    /* 2. Va a entrar en Sleep: Encendemos el LED rojo (PB14) */
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14, GPIO_PIN_SET);
    
    /* 3. �TRUCO VITAL! Suspendemos el "reloj interno" del RTOS. 
       Si no hacemos esto, el RTOS despertar� al procesador en 1 milisegundo */
    HAL_SuspendTick();
    
    /* 4. EL BUCLE TRAMPA */
    boton_pulsado = 0; /* Lo ponemos a cero antes de dormir */
    while(boton_pulsado == 0) {
        /* Si se despierta por la red, como boton_pulsado sigue en 0, 
           el bucle da la vuelta y la manda a dormir otra vez al instante. */
        HAL_PWR_EnterSLEEPMode(PWR_MAINREGULATOR_ON, PWR_SLEEPENTRY_WFI);
    }
    
    /* --- EL PROCESADOR EST� CONGELADO AQU� HASTA QUE PULSES EL BOT�N AZUL --- */
    
    /* 5. Al despertar, restauramos el reloj interno del RTOS */
    HAL_ResumeTick();
    
    /* 6. Apagamos el LED rojo nada m�s salir del modo Sleep */
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14, GPIO_PIN_RESET);
    
    /* Fin. El hilo termina y el sistema vuelve a la normalidad */
    osThreadExit();
}

/*----------------------------------------------------------------------------
  Main Thread 'main': Run Network
 *---------------------------------------------------------------------------*/
__NO_RETURN void app_main (void *arg) {
  (void)arg;
  //LCD_reset(); // Configura SPI y GPIOs seg�n tu lcd.c 
  //LCD_init();  // Env�a los comandos de configuraci�n al controlador del LCD
  LED_Initialize();
  Buttons_Initialize();
  //ADC_Initialize();
   ADC1_pins_F429ZI_config();
  ADC_Init_Single_Conversion(&adcHANDLE, ADC1);
  netInitialize ();
  Init_Boton_Despertador(); // Inicializamos la interrupci�n del bot�n

  //TID_Led     = osThreadNew (BlinkLed, NULL, NULL);
  TID_Display = osThreadNew (Display,  NULL, NULL);
  TID_SNTP     = osThreadNew (SNTP_Thread, NULL, NULL);
  
  TID_ParpadeoVerde = osThreadNew(Parpadeo_Verde_Thread, NULL, NULL);
  TID_SleepControl = osThreadNew(Sleep_Control_Thread, NULL, NULL);
  
  osThreadExit();
}
