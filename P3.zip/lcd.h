#ifndef __LCD_H
#define __LCD_H


#include <Driver_SPI.h>
#include <stdio.h>
#include "stm32f4xx_hal.h"


void LCD_reset(void);
void LCD_wr_data(unsigned char data);
void LCD_wr_cmd(unsigned char cmd);
void LCD_init(void);
void LCD_update(void);
void LCD_clean(void);
void charToLocalBuffer(uint8_t line, const char *text);

//void symbolToLocalBuffer_L1(uint8_t symbol);
//void symbolToLocalBuffer_L2(uint8_t symbol);
void symbolToLocalBuffer(uint8_t line,uint8_t symbol);

#endif 
