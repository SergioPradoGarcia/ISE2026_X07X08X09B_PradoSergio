#ifndef __RTC_H
#define __RTC_H

#include "stm32f4xx_hal.h"

/* Exponemos el manejador del RTC por si el main lo necesita */
extern RTC_HandleTypeDef hrtc;

/* Cabeceras de las funciones que pide la pr�ctica */
void RTC_Init(void);
void RTC_CalendarShow(char *showtime, char *showdate);
static void RTC_CalendarConfig(void);
static void RTC_AlarmConfig(void);
void get_time(void);
void Parpadeo_led_rojo(void);
static void time_callback (uint32_t seconds, uint32_t seconds_fraction);
void reset_tiempo(void);

#endif /* __RTC_H */
