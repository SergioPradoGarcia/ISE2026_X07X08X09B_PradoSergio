#ifndef __THPOT_H
#define __THPOT_H

	#include "cmsis_os2.h" 
	#include "stm32f4xx_hal.h"

	void Init_Boton_Despertador(void);

#endif
